runtime per video [s] : 0.2
CPU[1] / GPU[0] : 0
Extra Data [1] / No Extra Data [0] : 0
Other description : Solution based on A+ of Timofte et al. ACCV 2014. We have a Matlab/C++ implementation, and report single core CPU runtime. The method was trained on Train 91 of Yang et al. and BSDS 200 of the Berkeley segmentation dataset. 